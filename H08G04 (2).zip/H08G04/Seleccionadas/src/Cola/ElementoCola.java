package Cola;

public class ElementoCola<T> {
    T dato;
    ElementoCola<T> siguiente;

    public ElementoCola(T dato) {
        this.dato=dato;
        this.siguiente=null;
    }
}
