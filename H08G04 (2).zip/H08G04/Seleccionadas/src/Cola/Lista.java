package Cola;

public interface Lista<T> {
    void push(T dato);
    T pop();
    boolean isEmpty();
    void imprimirCola();
    T peek();
    int size();
    void clear();
}
