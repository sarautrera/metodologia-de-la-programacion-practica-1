package Cola;
import TestMain.Perros;
public class cola<T> implements Lista<T> {
    protected ElementoCola<T> ultimo;
    protected ElementoCola<T> primero;

    public cola(){this.ultimo=null;}
    //Añadir elementos
    @Override
    public void push(T dato){
        ElementoCola<T> nuevo =new ElementoCola<>(dato);
        if (isEmpty()){
            primero=nuevo;
            ultimo=nuevo;
        }
        else{
        ultimo.siguiente=nuevo;
        ultimo=nuevo;
        }
    }
    //Quitar elementos
    @Override
    public T pop() {
        if (isEmpty()) return null;
        T dato = primero.dato;
        primero = primero.siguiente;

        if (primero == null) {
            ultimo = null;
        }
        return dato;
    }
    @Override
    public boolean isEmpty(){return ultimo==null;}
    @Override
    public void imprimirCola(){
        ElementoCola<T> actual = primero;
        while (actual != null){
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }
    //metodo para saber quien esta al frente de la cola
    @Override
    public T peek(){
        if (isEmpty()) {
            return null;
        }
        return primero.dato;
    }
    @Override
    public int size(){
        int contador =0;
        if (isEmpty()){
            return 0;
        }
        else{
            ElementoCola<T> actual = primero;
            while (actual != null){
                actual=actual.siguiente;
                contador++;
            }
        }
        return contador;
    }
    @Override
    public void clear(){
        primero=null;
        ultimo = null;
    }
}
