package ListaCircular;

public interface IListaCircular<T> {
    void insertar(T dato);
    void saltarSiguiente(); // Nueva función: mover el puntero al siguiente turno
}