package ListaCircular;

/**
 * Representa una lista circular donde el último elemento apunta al primero.
 * Ideal para gestionar turnos en un juego.
 */
public class ListaCircularJuego<T> {

    // Nodo interno privado para encapsular la estructura
    private class Nodo {
        T dato;
        Nodo siguiente;
        Nodo(T d) { this.dato = d; }
    }

    private Nodo primero;
    private Nodo ultimo;

    /**
     * Inserta un nuevo jugador al final de la lista.
     * @param dato El nombre o identificador del jugador.
     */
    public void insertar(T dato) {
        Nodo nuevo = new Nodo(dato);
        if (primero == null) {
            primero = ultimo = nuevo;
            ultimo.siguiente = primero; // Cierre del ciclo
        } else {
            ultimo.siguiente = nuevo;
            ultimo = nuevo;
            ultimo.siguiente = primero; // Mantiene la circularidad
        }
    }

    /**
     * Mueve el puntero principal al siguiente nodo, simulando un cambio de turno.
     */
    public void pasarTurno() {
        if (primero != null) {
            primero = primero.siguiente;
            ultimo = ultimo.siguiente;
        }
    }

    /**
     * Devuelve el jugador que tiene el turno actual.
     */
    public T verTurnoActual() {
        return (primero != null) ? primero.dato : null;
    }
}