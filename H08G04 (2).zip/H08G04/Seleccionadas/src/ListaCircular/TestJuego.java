package ListaCircular;

public class TestJuego {
    public static void main(String[] args) {
        ListaCircularJuego<String> partida = new ListaCircularJuego<>();

        partida.insertar("Jugador 1");
        partida.insertar("Jugador 2");
        partida.insertar("Jugador 3");

        System.out.println("Turno actual: " + partida.verTurnoActual());
        partida.pasarTurno();
        System.out.println("Nuevo turno tras rotar: " + partida.verTurnoActual());
    }
}