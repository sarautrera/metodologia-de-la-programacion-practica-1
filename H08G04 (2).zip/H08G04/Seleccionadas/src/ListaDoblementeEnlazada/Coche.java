package ListaDoblementeEnlazada;

public class Coche implements Comparable<Coche> {
    private String matricula;
    private String modelo;

    public Coche(String matricula, String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public String toString() {
        return "Coche{" + "Mat='" + matricula + '\'' + ", Mod='" + modelo + '\'' + '}';
    }

    public int compareTo(Coche another) {
        return this.matricula.compareTo(another.getMatricula());
    }

}
