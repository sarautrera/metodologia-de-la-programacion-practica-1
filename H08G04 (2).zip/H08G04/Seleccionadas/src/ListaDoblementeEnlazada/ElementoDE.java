package ListaDoblementeEnlazada;

public class ElementoDE<T> {
    T dato;
    ElementoDE<T> siguiente;
    ElementoDE<T> anterior;

    ElementoDE(T dato){
        this.dato=dato;
        this.siguiente=null;
        this.anterior=null;
    }

}
