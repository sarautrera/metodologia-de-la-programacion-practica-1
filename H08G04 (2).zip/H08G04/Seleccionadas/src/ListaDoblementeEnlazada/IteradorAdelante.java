package ListaDoblementeEnlazada;

public class IteradorAdelante<T> {
    private ElementoDE<T> actual;
    public IteradorAdelante(ElementoDE<T> primero){
        this.actual =primero;
    }
    public boolean hasNext(){
        //hay siguiente si el nodo actual no es null
        return actual != null;
    }
    public T next(){
        if (actual == null){
            return null;
        }
        T dato =actual.dato;
        actual = actual.siguiente;
        return dato;
    }
}
