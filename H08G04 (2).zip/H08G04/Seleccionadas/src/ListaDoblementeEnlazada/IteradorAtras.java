package ListaDoblementeEnlazada;

public class IteradorAtras<T> {
    private ElementoDE<T> actual;
    public IteradorAtras(ElementoDE<T> ultimo){
        this.actual = ultimo;
    }
    public boolean hasPrevious() {
        // Si actual es null, ya no hay más elementos hacia atrás
        return actual != null;
    }
    public T previous() {
        if (actual == null) return null;

        T dato = actual.dato;
        actual = actual.anterior; // Aquí está el movimiento clave
        return dato;
    }
}
