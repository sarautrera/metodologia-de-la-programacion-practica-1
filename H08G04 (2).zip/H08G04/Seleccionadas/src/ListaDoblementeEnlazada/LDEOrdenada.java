package ListaDoblementeEnlazada;

public class LDEOrdenada<T extends Comparable<T>> implements Lista<T>{
    private int tamaño;
    private ElementoDE<T> primero;
    private ElementoDE<T> ultimo;

    @Override
    public void add(T dato) {
        ElementoDE<T> nuevo = new ElementoDE<>(dato);
        //una lista ordenada va de menor a mayor
        // CASO A: Lista vacía
        if (isEmpty()) {
            primero = nuevo;
            ultimo = nuevo;
            //CASO B: el dato  más pequeño (va al principio)
        } else if (primero.dato.compareTo(dato) > 0) {
            nuevo.siguiente = primero;//primero es el nodo que originalmente esta al inicio, el nuevo debe apuntar a este
            primero.anterior = nuevo;//entonces el primero debe esta unido por atras al nuevo, ahora primero
            primero = nuevo;
        }
        // CASO C: El dato es mayor o igual al último (va al final)
        else if (ultimo.dato.compareTo(dato) <= 0) {
            nuevo.anterior = ultimo;//conectamos el nuevo al ultimo
            ultimo.siguiente = nuevo;//conectamos el ultimo al nuevo
            ultimo = nuevo;//decimos que el nuevo es el ultimo
        } else {
            // CASO D: Inserción en medio(entre actual y actual.siguiente)
            ElementoDE<T> actual = primero;
            while (actual.siguiente != null && actual.siguiente.dato.compareTo(dato) < 0) {
                //Mientras sea menor que el actual y no nulo, no salimos del while
                actual = actual.siguiente;
            }
            //Conectar el nuevo nodo(entre actual y actual.siguiente)
            nuevo.siguiente = actual.siguiente;
            nuevo.anterior = actual;

            //Actualizar los vecinos
            actual.siguiente.anterior = nuevo;
            actual.siguiente = nuevo;
        }
        tamaño++;
    }
    @Override
    public T get(T dato){
        ElementoDE<T> aux = primero;
        while (aux !=null && aux.dato.compareTo(dato)<0) {
            aux = aux.siguiente;
        }
        if(aux!= null && aux.dato.compareTo(dato)==0){
            return aux.dato;
        }
        return null;
    }
    @Override
    public T del(T dato) {
        ElementoDE<T> aux = primero;
        while (aux != null) {
            if (aux.dato.compareTo(dato) == 0) {
                if (aux.anterior != null) aux.anterior.siguiente = aux.siguiente;
                else primero = aux.siguiente;

                if (aux.siguiente != null) aux.siguiente.anterior = aux.anterior;
                else ultimo = aux.anterior;

                tamaño--;
                return aux.dato;
            }
            aux = aux.siguiente;
        }
        return null;
    }
    @Override public boolean isEmpty(){
        return primero==null;
    }
    @Override public int getSize(){
        return tamaño;
    }
    public T getFirst() {
        if (isEmpty()) return null;
        return primero.dato;
    }


    @Override
    public T getLast() {
        if (isEmpty()) {
            return null;
        }
        ElementoDE<T> aux = primero;
        while (aux.siguiente != null) {
            aux=aux.siguiente;
        }
        // Al salir del bucle, aux es el último nodo
        return aux.dato;
    }
    @Override
    public void deleteDuplicados(){
        if (isEmpty()) return;
        ElementoDE<T> actual = primero;
        while(actual.siguiente != null){
            if(actual.dato.compareTo(actual.siguiente.dato)==0){
                //Lo borramos 'saltandolo', haciendo que el siguiente apunte al siguiente siguiente
                actual.siguiente=actual.siguiente.siguiente;
                if (actual.siguiente.siguiente != null) {
                    actual.siguiente.siguiente.anterior = actual;
                } else {
                    // Si el duplicado era el último, el 'ultimo' de la lista ahora es 'actual'
                    ultimo = actual;
                }
                tamaño--;

            }else{
                actual=actual.siguiente;
            }
        }
    }
    @Override
    public void merge(Lista<T> another){
        if (another.isEmpty()) return;
        IteradorAdelante<T> i1=another.getIterador();
        while(i1.hasNext()){
            add(i1.next());
        }
    }
    @Override
    public void clear() {
        primero = null;
        tamaño=0;
    }
    @Override
    public void imprimirReverse(Lista<T> a){
        IteradorAtras<T> it =a.getReverseIterador();
        while (it.hasPrevious()) {
            System.out.println(it.previous());
        }
    }
    @Override
    public void imprimir(Lista<T> a){
        IteradorAdelante<T> it =a.getIterador();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
    @Override public IteradorAdelante<T> getIterador(){return new IteradorAdelante<T>(primero);}
    @Override public IteradorAtras<T> getReverseIterador(){return new IteradorAtras<T>(ultimo);}
}

