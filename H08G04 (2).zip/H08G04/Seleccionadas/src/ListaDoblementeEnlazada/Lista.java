package ListaDoblementeEnlazada;

public interface Lista<T extends Comparable<T>> {
    void add(T dato);
    T get(T dato);
    T del(T dato);
    boolean isEmpty();
    int getSize();
    IteradorAdelante<T> getIterador();
    IteradorAtras<T> getReverseIterador();
    T getLast();
    void deleteDuplicados();
    T getFirst();
    void merge(Lista<T> another);
    void clear();
    void imprimirReverse(Lista<T> a);
    void imprimir(Lista<T> a);


}
