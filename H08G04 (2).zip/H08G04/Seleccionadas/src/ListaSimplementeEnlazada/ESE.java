package ListaSimplementeEnlazada;

//cada elemento de la lista contiene su valor y el posicionamiento de cada elemento
public class ESE<T> {
    public T valor;//dato del elemento
    public ESE<T> siguiente;//puntero al siguiente elemento
    public ESE(T valor){
        this.valor=valor;
        this.siguiente=null;//esta posicion se rellena al generarse el siguiente elemento
    }


}
