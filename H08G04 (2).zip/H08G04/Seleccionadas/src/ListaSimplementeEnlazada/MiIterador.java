package ListaSimplementeEnlazada;


public interface MiIterador<T> {
    boolean hasNext(); // Sin cuerpo
    T next();        // Sin cuerpo
}