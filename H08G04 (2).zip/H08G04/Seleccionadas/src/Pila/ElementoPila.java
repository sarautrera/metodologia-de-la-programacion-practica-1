package Pila;

public class ElementoPila<T> {
    public T dato;
    public ElementoPila<T> siguiente;

    public ElementoPila(T dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}
