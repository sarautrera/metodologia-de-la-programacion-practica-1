package Pila;

public interface Lista<T>  {
    void push(T elemento);
    T pop();
    boolean isEmpty();
    int size();
    void imprimirPila();
    T peek();
    void clear();
    void invertir();
    void insertarAlFondo(T dato);

}
