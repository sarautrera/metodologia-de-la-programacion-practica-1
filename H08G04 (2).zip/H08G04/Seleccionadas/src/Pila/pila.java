package Pila;
import TestMain.Perros;
public class pila<T> implements Lista<T> {
    protected ElementoPila<T> cima;

    public pila(){
        this.cima=null;
    }
    //Añadir elementos
    @Override
    public void push(T dato){
        ElementoPila<T> nuevo =new ElementoPila<>(dato);
        nuevo.siguiente=cima;
        cima=nuevo;
    }
    //Quitar elementos
    @Override
    public T pop() {
        if (isEmpty()) return null;
        T dato = cima.dato;
        cima = cima.siguiente;
        return dato;
    }
    @Override
    public boolean isEmpty() {
        return cima == null;
    }
    @Override
    public void imprimirPila() {
        ElementoPila<T> actual = cima; // Creamos una referencia temporal
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente; // Saltamos al siguiente sin cambiar 'cima'
        }
    }
    @Override
    public int size(){
        int count = 0;
        ElementoPila<T> actual=cima;
        while (actual != null){
            count ++;
            actual=actual.siguiente;
        }
        return count;
    }
    //Este metodo lo usamos para ver que hay arriba del todo(para saber que vamos a borrar)
    @Override
    public T peek(){
        if (isEmpty()) return null;
        return cima.dato;
    }
    //Limpia la pila
    @Override
    public void clear(){
        cima=null;
    }
    //Invierte el orden de los datos
    @Override
    public void invertir(){
        if (!isEmpty()) {// CASO BASE (si está vacía, ya terminamos)
            // 1. Sacamos el elemento superior (la cima)
            T dato = pop();

            // 2. Invertimos el resto de la pila (recursión)
            invertir();

            // 3. Insertamos el elemento en el fondo (insertarAlFondo)
            insertarAlFondo(dato);
        }

    }
    //Inserta dato al fondo(sin cambiar el orden establecido)
    @Override
    public void insertarAlFondo(T dato) {
        if (isEmpty()) {
            push(dato);
        } else {
            //Cada llamada tiene su propia variable local
            // primero hacemos pop y guardamos los elementos en variable temporales, y una vez que la pila está vacia lo llenamos con push
            T cimaTemporal = pop();//Saco el dato que habia
            insertarAlFondo(dato); //Llamada al método
            push(cimaTemporal);
        }
        //En recusrividad, una vez que llegamos al caso base, sigue ejecutando lo que tiene abajo
    }
}
