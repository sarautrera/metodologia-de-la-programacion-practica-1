package TestMain;

public class Perros {
    private String nombre;
    private String raza;

    public Perros(String nombre, String raza){
        this.nombre=nombre;
        this.raza=raza;
    }
    @Override
    public String toString(){
        return "Perro[ nombre: "+nombre+", raza: "+raza+"]";
    }
}
