package TestMain;


import Cola.cola;
import ListaCircular.ListaCircularJuego;
import ListaDoblementeEnlazada.Coche;
import ListaDoblementeEnlazada.LDEOrdenada;
import ListaDoblementeEnlazada.Lista;
import Pila.pila;
import Pila.ElementoPila;
import ListaSimplementeEnlazada.ListaSimpleEnlazada;
import ListaSimplementeEnlazada.MiIterador;

public class TestMain {
    public static void main(String[] args) {
        /** PILA
         */
        System.out.println("PILA---------------------------------");
        pila<Perros> misPerros = new pila<>();

        System.out.println("¿Está vacía? " + misPerros.isEmpty());
        misPerros.push(new Perros("Nugget", "Rotwailer"));
        misPerros.push(new Perros("Rayo", "Border Collie"));
        misPerros.push(new Perros("T-Rex", "Perro salchicha"));
        misPerros.imprimirPila();
        System.out.println("Tamaño de la lista: " + misPerros.size());

        System.out.println("¿Está vacía? " + misPerros.isEmpty());
        System.out.println("Borrando elemento 1");
        misPerros.pop();
        System.out.println("Borrando elemento 2");
        misPerros.pop();
        System.out.println("Borrando elemento 3");
        misPerros.pop();

        System.out.println("¿Está vacía? " + misPerros.isEmpty());
        System.out.println("Tamaño de la lista: " + misPerros.size());

        System.out.println("Llenamos la lista");

        misPerros.push(new Perros("Nugget", "Rotwailer"));
        misPerros.push(new Perros("Rayo", "Border Collie"));
        misPerros.push(new Perros("T-Rex", "Perro salchicha"));

        Perros p1 = new Perros("Firulais", "Caniche");
        ElementoPila<Perros> nuevoNodo = new ElementoPila<>(p1);
        misPerros.insertarAlFondo(p1);

        System.out.println("El elemento superior es: " + misPerros.peek());
        misPerros.imprimirPila();

        misPerros.invertir();
        System.out.println("El elemento superior es: " + misPerros.peek());

        System.out.println("Borrando lista...");
        misPerros.clear();
        System.out.println("Tamaño de la lista: " + misPerros.size());

        /** LISTA SIMPLEMENTE ENLAZADA
         */
        System.out.println("LISTA SIMPLEMENTE ENLAZADA------------------");
        System.out.println("=== TEST DEL FESTIVAL (LISTA ENLAZADA) ===");

        // Nota: Si LSEOrdenada ya ordena alfabéticamente, cambia el 'new'
        ListaSimpleEnlazada<String> cartel = new ListaSimpleEnlazada<>();

        System.out.println("Registrando bandas en el sistema...");
        cartel.add_cabeza("The Beatles");
        cartel.add_cabeza("Aitana");
        cartel.add_final("Melendi");
        cartel.add_cabeza("Queen");
        cartel.add_final("Quevedo");

        System.out.println("Total de artistas confirmados: " + cartel.getSize());

        // Verificamos el orden con el Iterador personalizado
        System.out.println("\nLine-up actual:");
        MiIterador<String> it = cartel.getIterador();
        int puesto = 1;
        while (it.hasNext()) {
            System.out.println(puesto + ". " + it.next());
            puesto++;
        }

        // Verificación de existencia
        String banda = "The Beatles";
        if (cartel.existe(banda)) {
            System.out.println("\nConfirmado: " + banda + " está en la lista.");
            System.out.println("Posición en el programa: " + cartel.buscar(banda, 0));
        }

        // Gestión de bajas
        System.out.println("\nModificando cartel: Aitana se retira del evento.");
        if (cartel.del_valor("Aitana")) {
            System.out.println("Lista actualizada con éxito.");
        }

        // Estado final del festival
        System.out.println("\nCartel definitivo del evento:");
        MiIterador<String> itFinal = cartel.getIterador();
        while (itFinal.hasNext()) {
            System.out.print("[" + itFinal.next() + "] ");
        }
        /** LISTA DOBLEMENTE ENLAZADA
         */
        System.out.println("LISTA DOBLEMENTE ENLAZADA------------------");
        //Creamos la lista de coches
        LDEOrdenada<Coche> misCoches = new LDEOrdenada<>();

        //Añadimos algunos coches
        misCoches.add(new Coche("1234BBB", "Seat"));
        misCoches.add(new Coche("9012DDD", "Audi"));
        misCoches.add(new Coche("5678CCC", "Ford"));
        misCoches.add(new Coche("5678CCC", "Ford"));
        System.out.println("--- Listado de coches ---");
        misCoches.imprimir(misCoches);
        System.out.println("Tamaño de la lista: " + misCoches.getSize());
        misCoches.deleteDuplicados();
        System.out.println("Eliminando duplicado...");
        //Recorremos la lista con el iterador que tenemos
        System.out.println("--- Listado de coches ---");
        misCoches.imprimir(misCoches);
        System.out.println("--- Borrando el coche 5678CCC ---");
        Coche aBorrar = new Coche("5678CCC", ""); // Solo importa la matrícula para el equals
        Coche borrado = misCoches.del(aBorrar);
        if (borrado != null) {
            System.out.println("Se ha borrado: " + borrado);
        }

        // PRUEBA CLAVE: Recorrido inverso real
        System.out.println("--- Recorriendo de atrás hacia atras ---");
        misCoches.imprimirReverse(misCoches);

        System.out.println("\nBuscando 1234BBB: " + misCoches.get(new Coche("1234BBB", "")));
        Lista<Coche> masCoches = new LDEOrdenada<>();
        masCoches.add(new Coche("DDD456", "Ford"));
        masCoches.add(new Coche("EEE789", "Ferrari"));

        misCoches.merge(masCoches);
        misCoches.imprimir(misCoches);
        System.out.println("Primer elemento: " + misCoches.getFirst());
        System.out.println("Ultimo elemento: " + misCoches.getLast());
        System.out.println("Tamaño de la lista: " + misCoches.getSize());
        System.out.println("Limpiando...");
        misCoches.clear();
        System.out.println("Tamaño: " + misCoches.getSize());

        /** COLA
         */
        System.out.println("COLA------------------------");
        cola<Perros> miPerros = new cola<>();

        System.out.println("¿Está vacía? " + miPerros.isEmpty());
        miPerros.push(new Perros("Nugget", "Rotwailer"));
        miPerros.push(new Perros("Rayo", "Border Collie"));
        miPerros.push(new Perros("T-Rex", "Perro salchicha"));
        miPerros.imprimirCola();

        System.out.println("¿Está vacía? " + miPerros.isEmpty());
        System.out.println("Tamaño: " + miPerros.size());

        System.out.println("Borrando elemento 1");
        miPerros.pop();
        System.out.println("Borrando elemento 2");
        miPerros.pop();
        System.out.println("Borrando elemento 3");
        miPerros.pop();

        System.out.println("¿Está vacía? " + miPerros.isEmpty());
        System.out.println("Tamaño: " + miPerros.size());

        miPerros.push(new Perros("Nugget", "Rotwailer"));
        miPerros.push(new Perros("Rayo", "Border Collie"));
        miPerros.push(new Perros("T-Rex", "Perro salchicha"));
        System.out.println("El primer elemento es: " + miPerros.peek());
        System.out.println("Llenamos de nuevo la lista(tamaño): " + miPerros.size());
        miPerros.imprimirCola();
        miPerros.clear();
        System.out.println("Borramos todo de una vez(tamaño): " + miPerros.size());

        /** LISTA CIRCULAR
         */
        System.out.println("PLISTA CIRCULAR-----------------------");
        ListaCircularJuego<String> partida = new ListaCircularJuego<>();

        partida.insertar("Jugador 1");
        partida.insertar("Jugador 2");
        partida.insertar("Jugador 3");

        System.out.println("Turno actual: " + partida.verTurnoActual());
        partida.pasarTurno();
        System.out.println("Nuevo turno tras rotar: " + partida.verTurnoActual());
    }

}




